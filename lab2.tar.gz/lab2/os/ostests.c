#include "ostraps.h"
#include "dlxos.h"
#include "traps.h"
#include "synch.h"

void RunOSTests() {
  // Student: run any os-level tests here
  printf("RunOSTests: Begin\n");
  printf("RunOSTests: End\n");
}
